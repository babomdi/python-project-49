#!/usr/bin/env python3
from brain_games.even import even_logic


def main():
    even_logic()


if __name__ == '__main__':
    main()
